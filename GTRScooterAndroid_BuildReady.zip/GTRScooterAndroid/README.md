# GTR Scooter Android prototype

Prototype Android app for BLE scanning, listing nearby Bluetooth devices, connecting to a selected device, and showing discovered GATT service UUIDs. It deliberately does not send vehicle commands because the BT-GTR protocol is not yet known.


## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s). Requires Android Studio and Android SDK (API 35).

## Test
1. Install debug APK on Android phone.
2. Enable Bluetooth and grant scan/connect permissions.
3. Turn scooter on and scan; select BT-GTR.
4. Record the GATT service UUIDs displayed for protocol investigation.

This is a prototype project, not a verified vehicle controller.
