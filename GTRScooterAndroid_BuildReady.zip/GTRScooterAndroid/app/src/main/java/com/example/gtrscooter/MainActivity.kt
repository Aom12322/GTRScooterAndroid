package com.example.gtrscooter

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.content.Context

class MainActivity : Activity() {
    private val btManager by lazy { getSystemService(BluetoothManager::class.java) }
    private var scanner: BluetoothLeScanner? = null
    private var scanning = false
    private var gatt: BluetoothGatt? = null
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val found = linkedMapOf<String, BluetoothDevice>()
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) { addDevice(result.device, result.rssi) }
        override fun onBatchScanResults(results: MutableList<ScanResult>) { results.forEach { addDevice(it.device, it.rssi) } }
        override fun onScanFailed(errorCode: Int) { status.text = "สแกนล้มเหลว: $errorCode"; scanning = false }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12,18,28); window.navigationBarColor = Color.rgb(12,18,28)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,30,24,24); setBackgroundColor(Color.rgb(12,18,28)) }
        root.addView(TextView(this).apply { text="GTR SCOOTER"; textSize=26f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(0,0,0,16) })
        root.addView(TextView(this).apply { text="Android Bluetooth dashboard • prototype"; textSize=14f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER; setPadding(0,0,0,20) })
        status = TextView(this).apply { text="พร้อมค้นหา Bluetooth"; textSize=16f; setTextColor(Color.rgb(80,220,160)); gravity=Gravity.CENTER; setPadding(0,12,0,12) }
        root.addView(status)
        val scanBtn = Button(this).apply { text="ค้นหา BT-GTR / Bluetooth"; setOnClickListener { requestAndScan() } }
        root.addView(scanBtn)
        root.addView(TextView(this).apply { text="อุปกรณ์ที่พบ (แตะเพื่อเชื่อมต่อ)"; textSize=16f; setTextColor(Color.WHITE); setPadding(0,18,0,8) })
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(TextView(this).apply { text="หมายเหตุ: รุ่นทดลองนี้ค้นหาและเชื่อมต่อ BLE ได้ แต่ยังไม่ส่งคำสั่งควบคุมรถจนกว่าจะทราบโปรโตคอล BT-GTR เพื่อความปลอดภัย" ; textSize=12f; setTextColor(Color.LTGRAY); setPadding(0,24,0,0 })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private fun requestAndScan() { val p=requiredPermissions(); if(p.any { checkSelfPermission(it)!=PackageManager.PERMISSION_GRANTED }) requestPermissions(p, 10) else startScan() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, results:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,results); if(requestCode==10 && results.all { it==PackageManager.PERMISSION_GRANTED }) startScan() else status.text="ต้องอนุญาต Bluetooth เพื่อสแกน" }
    private fun startScan() {
        val adapter=btManager.adapter
        if(adapter==null || !adapter.isEnabled) { status.text="กรุณาเปิด Bluetooth"; return }
        scanner=adapter.bluetoothLeScanner; found.clear(); list.removeAllViews(); scanning=true; status.text="กำลังสแกน… เปิดรถไว้ใกล้มือถือ"
        try { scanner?.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback); list.postDelayed({ stopScan(); if(found.isEmpty()) status.text="ไม่พบอุปกรณ์ ลองสแกนอีกครั้ง" else status.text="พบ ${found.size} อุปกรณ์" }, 12000) } catch(e: SecurityException) { status.text="Bluetooth permission denied" }
    }
    private fun stopScan() { if(scanning) try { scanner?.stopScan(scanCallback) } catch(_:Exception){}; scanning=false }
    private fun addDevice(device:BluetoothDevice, rssi:Int) {
        val name=try { device.name ?: "Unknown device" } catch(_:SecurityException){ "Bluetooth device" }
        val key=device.address; if(found.containsKey(key)) return; found[key]=device
        runOnUiThread { val b=Button(this).apply { text="$name  •  $rssi dBm\n$key"; setOnClickListener { connect(device,name) } }; list.addView(b) }
    }
    private fun connect(device:BluetoothDevice,name:String) { stopScan(); status.text="กำลังเชื่อมต่อ $name…"; try { gatt?.close(); gatt=device.connectGatt(this,false,object:BluetoothGattCallback(){ override fun onConnectionStateChange(g:BluetoothGatt,statusCode:Int,newState:Int){ runOnUiThread { status.text=if(newState==BluetoothProfile.STATE_CONNECTED) "เชื่อมต่อแล้ว: $name • กำลังอ่านบริการ" else "ตัดการเชื่อมต่อ (code $statusCode)" }; if(newState==BluetoothProfile.STATE_CONNECTED) g.discoverServices() }; override fun onServicesDiscovered(g:BluetoothGatt,statusCode:Int){ runOnUiThread { val services=g.services?.joinToString("\n") { it.uuid.toString() } ?: "ไม่พบบริการ"; status.text="เชื่อมต่อ $name\nบริการ BLE:\n$services" } } }) } catch(e:Exception){ status.text="เชื่อมต่อไม่สำเร็จ: ${e.message}" } }
 override fun onDestroy(){ stopScan(); gatt?.disconnect(); gatt?.close(); super.onDestroy() }
}
